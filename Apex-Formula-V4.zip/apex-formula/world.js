/* THREE scene: lightweight track, original low-poly cars and themed scenery. */
(function(){
  'use strict';
  const T=window.THREE;
  function mat(color,rough=1,metal=0,extra){return new T.MeshStandardMaterial(Object.assign({color,roughness:rough,metalness:metal},extra||{}))}
  function box(g,material,x,y,z,sx,sy,sz){const m=new T.Mesh(new T.BoxGeometry(sx,sy,sz),material);m.position.set(x,y,z);g.add(m);return m}
  function frame(track,i){
    const s=track.samples[(i+track.count)%track.count], t=(s.tangent&&s.tangent.lengthSq()>0?s.tangent:new T.Vector3().subVectors(track.samples[(i+1)%track.count].p,track.samples[(i+track.count-1)%track.count].p)).clone().normalize();
    return {s,t,n:new T.Vector3(t.z,0,-t.x).normalize(),bank:s.bank||0};
  }
  function trackBounds(track){
    let minX=Infinity,maxX=-Infinity,minZ=Infinity,maxZ=-Infinity;
    track.samples.forEach(s=>{minX=Math.min(minX,s.p.x);maxX=Math.max(maxX,s.p.x);minZ=Math.min(minZ,s.p.z);maxZ=Math.max(maxZ,s.p.z)});
    return {minX,maxX,minZ,maxZ,cx:(minX+maxX)/2,cz:(minZ+maxZ)/2,w:maxX-minX,d:maxZ-minZ,span:Math.max(maxX-minX,maxZ-minZ)};
  }
  // Every placed object uses this all-samples test, not just the nearest sample.
  function sceneryClear(track,p,clearance){
    const limit=clearance*clearance;
    for(let i=0;i<track.count;i++){
      const q=track.samples[i].p,dx=p.x-q.x,dz=p.z-q.z;
      if(dx*dx+dz*dz<limit)return false;
    }
    return true;
  }
  function addInstances(group,geometry,material,items){
    if(!items.length)return null;
    if(T.InstancedMesh){
      const mesh=new T.InstancedMesh(geometry,material,items.length),dummy=new T.Object3D();
      items.forEach((it,i)=>{dummy.position.copy(it.p);dummy.rotation.set(0,it.r||0,0);dummy.scale.set(it.s[0],it.s[1],it.s[2]);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix)});
      mesh.instanceMatrix.needsUpdate=true;group.add(mesh);return mesh;
    }
    // Older THREE fallback; the normal path is instanced and remains well below the draw-call budget.
    items.forEach(it=>{const m=new T.Mesh(geometry,material);m.position.copy(it.p);m.rotation.y=it.r||0;m.scale.set(it.s[0],it.s[1],it.s[2]);group.add(m)});
    return null;
  }
  function makeRoad(track){
    const pos=[],uv=[],w=track.width;
    for(let i=0;i<track.count;i++){
      const f=frame(track,i),bank=f.bank||0,edge=Math.sin(bank)*w/2;
      const a=f.s.p.clone().addScaledVector(f.n,w/2); a.y+=edge+.035;
      const b=f.s.p.clone().addScaledVector(f.n,-w/2); b.y-=edge-.035;
      pos.push(a.x,a.y,a.z,b.x,b.y,b.z);uv.push(i/track.count,0,i/track.count,1);
    }
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setAttribute('uv',new T.Float32BufferAttribute(uv,2));
    const inds=[];for(let i=0;i<track.count;i++){const q=i*2,j=((i+1)%track.count)*2;inds.push(q,q+1,j+1,q,j+1,j)}
    geo.setIndex(inds);geo.computeVertexNormals();return new T.Mesh(geo,mat(0x20282b,.96,0));
  }
  // A real continuous boundary ribbon, rather than the old duplicated/degenerate strip.
  function makeBoundary(track,side){
    const pos=[],w=track.width/2+.18,ribbon=.42;
    for(let i=0;i<track.count;i++){const f=frame(track,i),out=f.n.clone().multiplyScalar(side),c=f.s.p.clone().addScaledVector(out,w),bank=f.bank||0;c.y+=Math.sin(bank)*side*w;const a=c.clone().addScaledVector(out,-ribbon/2),b=c.clone().addScaledVector(out,ribbon/2);pos.push(a.x,a.y+.02,a.z,b.x,b.y+.02,b.z)}
    const inds=[];for(let i=0;i<track.count;i++){const q=i*2,j=((i+1)%track.count)*2;inds.push(q,q+1,j+1,q,j+1,j)}
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setIndex(inds);geo.computeVertexNormals();return new T.Mesh(geo,mat(0xe5dfce,.82,.05,{side:T.DoubleSide}));
  }
  function makeWall(track,side,material){
    const pos=[],w=track.width/2+.95,thick=.32;
    for(let i=0;i<track.count;i++){const f=frame(track,i),out=f.n.clone().multiplyScalar(side),c=f.s.p.clone().addScaledVector(out,w),bank=f.bank||0;c.y+=Math.sin(bank)*side*w;const inner=c.clone().addScaledVector(out,-thick/2),outer=c.clone().addScaledVector(out,thick/2);pos.push(inner.x,c.y,inner.z,outer.x,c.y,outer.z,inner.x,c.y+1.15,inner.z,outer.x,c.y+1.15,outer.z)}
    const inds=[];for(let i=0;i<track.count;i++){const q=i*4,j=((i+1)%track.count)*4;inds.push(q+2,q+3,j+3,q+2,j+3,j+2,q,q+2,j+2,q,j+2,j,q+1,j+1,j+3,q+1,j+3,q+3)}
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setIndex(inds);geo.computeVertexNormals();return new T.Mesh(geo,material);
  }
  function buildCar(team,player){
    const g=new T.Group();g.name=team.name;
    const body=mat(player?0x0a252c:team.body,.42,.35),accent=mat(player?0x35e2d0:team.accent,.3,.45),dark=mat(0x101619,.48,.65),tyre=mat(0x080b0c,.85),glass=mat(0x102b32,.08,.55);
    // Low, long monocoque with visible sidepods, wings and four proper open-wheel tyres.
    box(g,body,0,.31,0,1.18,.25,2.35);box(g,body,0,.38,-.22,.78,.16,1.18);
    box(g,body,-.55,.31,-.12,.28,.22,1.18);box(g,body,.55,.31,-.12,.28,.22,1.18);
    box(g,glass,0,.57,-.16,.48,.2,.62);box(g,accent,0,.46,.52,.76,.08,.72);
    box(g,accent,0,.25,1.37,1.85,.1,.34);box(g,accent,0,.34,-1.31,1.62,.13,.3);box(g,dark,0,.63,-.5,.1,.34,.68);
    const halo=new T.Mesh(new T.TorusGeometry(.24,.035,6,12,Math.PI*1.8),accent);halo.rotation.x=Math.PI/2;halo.position.set(0,.77,-.2);g.add(halo);
    [-.76,.76].forEach(x=>[-.78,.8].forEach(z=>{const w=new T.Mesh(new T.CylinderGeometry(.235,.235,.2,12),tyre);w.rotation.z=Math.PI/2;w.position.set(x,.25,z);g.add(w)}));
    box(g,body,0,.29,1.25,.28,.18,1.35);
    box(g,accent,0,.21,1.94,1.92,.09,.30);
    box(g,dark,-.52,.49,-1.31,.08,.3,.13);box(g,dark,.52,.49,-1.31,.08,.3,.13);
    box(g,accent,0,.70,-1.31,1.65,.10,.29);
    const driver=new T.Mesh(new T.SphereGeometry(.15,10,8),accent);driver.position.set(0,.67,-.08);g.add(driver);
    return g;
  }
  function addStreetScenery(group,track,b){
    const facadeA=mat(0xc5d3cf,.72,.05),facadeB=mat(0xd3aa83,.7,.08),roof=mat(0x304b55,.52,.2),window=mat(0x6ec4c6,.25,.35);
    const a=[],bb=[],r=[],w=[];
    for(let i=10;i<track.count;i+=13){
      const f=frame(track,i),side=i%3?1:-1,offset=track.width/2+18+(i%4)*6;
      const p=f.s.p.clone().addScaledVector(f.n,side*offset);p.addScaledVector(f.t,(i%3-1)*3);
      const sx=7+(i%3)*2,sz=8+(i%4)*2,sy=9+(i%5)*2;
      if(!sceneryClear(track,p,track.width/2+Math.max(sx,sz)*.72+2))continue;
      const item={p:p.clone().setY(p.y+sy/2),r:Math.atan2(f.t.x,f.t.z),s:[sx,sy,sz]};(i%2?a:bb).push(item);
      r.push({p:p.clone().setY(p.y+sy+.18),r:item.r,s:[sx*1.06,.36,sz*1.06]});
      for(let floor=2;floor<sy;floor+=2.3)w.push({p:p.clone().addScaledVector(f.t,sz*.505).setY(p.y+floor),r:item.r,s:[sx*.75,.45,.08]});
    }
    addInstances(group,new T.BoxGeometry(1,1,1),facadeA,a);addInstances(group,new T.BoxGeometry(1,1,1),facadeB,bb);addInstances(group,new T.BoxGeometry(1,1,1),roof,r);addInstances(group,new T.BoxGeometry(1,1,1),window,w);
    // A broad water strip and a few simple yachts give the street course a waterfront identity.
    const waterW=Math.max(32,b.w*.28),waterD=b.d+80,waterX=b.maxX+waterW*1.05;
    const waterMat=mat(0x286778,.32,.12,{transparent:true,opacity:.9});const water=new T.Mesh(new T.PlaneGeometry(waterW,waterD),waterMat);water.rotation.x=-Math.PI/2;water.position.set(waterX,-.025,b.cz);group.add(water);
    const hull=[],mast=[];for(let i=0;i<4;i++){
      const p=new T.Vector3(waterX-waterW*.28+(i%2)*waterW*.2,0,b.minZ+35+i*(waterD-70)/3);if(!sceneryClear(track,p,9))continue;
      const r=(i%2?-.2:.2);hull.push({p:p.clone().add(new T.Vector3(0,.18,0)),r,s:[4,.34,1.05]});mast.push({p:p.clone().add(new T.Vector3(0,1.25,0)),r:0,s:[.07,2.5,.07]});
    }
    addInstances(group,new T.BoxGeometry(1,1,1),mat(0xf2eee2,.6,.05),hull);addInstances(group,new T.BoxGeometry(1,1,1),mat(0xd9ece6,.5,.05),mast);
  }
  function addTrees(group,track,park){
    const trunk=[],crown=[],leafMat=mat(park?0x316b47:0x5a804d,.82,.02),trunkMat=mat(0x42382c,.92,.02);
    const total=park?76:18;
    for(let i=0;i<total;i++){
      const idx=(i*17+13)%track.count,f=frame(track,idx),side=i%2?1:-1,offset=track.width/2+15+(i%6)*5;
      const p=f.s.p.clone().addScaledVector(f.n,side*offset).addScaledVector(f.t,(i%5-2)*2);
      if(!sceneryClear(track,p,track.width/2+2.8))continue;
      const h=1.1+(i%4)*.18;trunk.push({p:p.clone().add(new T.Vector3(0,.7,0)),r:0,s:[.22,1.4,.22]});crown.push({p:p.clone().add(new T.Vector3(0,2.55+h,0)),r:0,s:[1.25+(i%3)*.18,2.8+h,1.25+(i%3)*.18]});
    }
    addInstances(group,new T.BoxGeometry(1,1,1),trunkMat,trunk);addInstances(group,new T.ConeGeometry(1,1,7),leafMat,crown);
  }
  function addAirfield(group,track,b){
    const runwayP=new T.Vector3(b.minX-72,0,b.cz),runwayRadius=59;
    if(sceneryClear(track,runwayP,runwayRadius)){
      const runway=box(group,mat(0x4d5758,.9),runwayP.x,.015,runwayP.z,14,.06,108);runway.rotation.y=0;
      const marks=[];for(let z=-45;z<=45;z+=15)marks.push({p:new T.Vector3(runwayP.x,.052,runwayP.z+z),r:0,s:[.32,.018,5]});
      addInstances(group,new T.BoxGeometry(1,1,1),mat(0xe4d9a2,.8),marks);
    }
    const stand=[],seat=[];for(let i=0;i<4;i++){
      const p=new T.Vector3(b.minX-45,0,b.minZ+25+i*(b.d-50)/3);if(!sceneryClear(track,p,16))continue;
      stand.push({p:p.clone().add(new T.Vector3(0,1.45,0)),r:0,s:[12,2.9,4]});seat.push({p:p.clone().add(new T.Vector3(0,3.2,0)),r:0,s:[12.5,.22,4.3]});
    }
    addInstances(group,new T.BoxGeometry(1,1,1),mat(0x858a87,.82),stand);addInstances(group,new T.BoxGeometry(1,1,1),mat(0xe7c66a,.6),seat);
  }

  function addThemeScenery(group,track,b){
    const count=track.count;
    if(track.kind==='monaco'||track.kind==='singapore'){
      const water=mat(track.kind==='singapore'?0x142c42:0x286778,.3,.15,{transparent:true,opacity:.92});
      const w=Math.max(28,b.w*.22),d=b.d+70,x=b.maxX+w*.9;
      const mesh=new T.Mesh(new T.PlaneGeometry(w,d),water);mesh.rotation.x=-Math.PI/2;mesh.position.set(x,-.03,b.cz);group.add(mesh);
      if(track.kind==='monaco'){
        const yachts=[];for(let i=0;i<7;i++){const p=new T.Vector3(x-w*.32+(i%3)*w*.18,b.cz*0+0,b.minZ+20+i*(d-40)/6);yachts.push({p:p.clone().setY(.25),r:(i%2?.15:-.15),s:[3.8,.4,1]})}addInstances(group,new T.BoxGeometry(1,1,1),mat(0xf2eee2,.55,.05),yachts);
      }
    }
    if(track.kind==='monza'){addTrees(group,track,true);}
    if(track.kind==='silverstone'){addTrees(group,track,true);const hedges=[];for(let i=0;i<count;i+=18){const f=frame(track,i),p=f.s.p.clone().addScaledVector(f.n,(track.width/2+12));if(sceneryClear(track,p,8))hedges.push({p:p.clone().setY(.65),r:Math.atan2(f.t.x,f.t.z),s:[5,.9,1.2]})}addInstances(group,new T.BoxGeometry(1,1,1),mat(0x294b32,.9),hedges);}
    if(track.kind==='spa'){addTrees(group,track,true);}
    if(track.kind==='suzuka'){addTrees(group,track,true);const torii=[];for(let i=20;i<count;i+=90){const f=frame(track,i),p=f.s.p.clone().addScaledVector(f.n,track.width/2+18);torii.push({p:p.clone().setY(2),r:Math.atan2(f.t.x,f.t.z),s:[4,.25,.35]})}addInstances(group,new T.BoxGeometry(1,1,1),mat(0xb52d35,.6,.05),torii);}
    if(track.kind==='interlagos'){addTrees(group,track,true);const hill=mat(0x315d38,.9);const hs=[];for(let i=0;i<18;i++){const f=frame(track,(i*47)%count),p=f.s.p.clone().addScaledVector(f.n,(track.width/2+28+(i%4)*7)*(i%2?1:-1));hs.push({p:p.clone().setY(2+(i%3)),r:0,s:[8+(i%3)*3,4+(i%2)*2,8+(i%4)]})}addInstances(group,new T.ConeGeometry(1,1,7),hill,hs);}
    if(track.kind==='singapore'){
      const lamps=[];for(let i=0;i<count;i+=28){const f=frame(track,i),p=f.s.p.clone().addScaledVector(f.n,track.width/2+4);lamps.push({p:p.clone().setY(3),r:Math.atan2(f.t.x,f.t.z),s:[.12,6,.12]})}addInstances(group,new T.BoxGeometry(1,1,1),mat(0x9b8cff,.4,.2),lamps);
      for(let i=0;i<Math.min(18,count/20);i++){const f=frame(track,i*50),light=new T.PointLight(0x9b8cff,1.1,38);light.position.copy(f.s.p).add(new T.Vector3(0,3.5,0));group.add(light)}
    }
  }
  function addTrackDetails(group,track){
    const boardMat=mat(0xf3eee2,.72,.02),dark=mat(0x182025,.7,.15),red=mat(0xd64f4b,.68,.08),white=mat(0xf5f1e6,.7,.02);
    const sectorMat=mat(track.color,.45,.15);
    // Sector timing lines: thin, high-contrast strips across the racing surface.
    (track.sectors||[0,.34,.69]).forEach((u,idx)=>{
      const a=APEX_TRACKS.at(track,u*track.length),line=box(group,sectorMat,a.p.x,a.p.y+.085,a.p.z,track.width*.96,.025,.18);
      line.rotation.y=a.heading; line.name='Sector '+(idx+1)+' line';
    });
    // Braking boards sit outside the racing line and are deliberately batched into simple meshes.
    const boards=[];(track.brakes||[]).forEach((u,idx)=>{
      const a=APEX_TRACKS.at(track,u*track.length),side=(idx%2?1:-1),p=a.p.clone().addScaledVector(a.normal,side*(track.width/2+2.5));
      boards.push({p:p.clone().setY(p.y+1.15),r:a.heading,s:[1.2,2.2,.16]});
      boards.push({p:p.clone().addScaledVector(a.tangent,-.08).setY(p.y+1.15),r:a.heading,s:[.86,1.18,.19]});
    });
    addInstances(group,new T.BoxGeometry(1,1,1),boardMat,boards);
    const brakeLabels=[];(track.brakes||[]).forEach((u,idx)=>{
      const a=APEX_TRACKS.at(track,u*track.length),side=(idx%2?1:-1),p=a.p.clone().addScaledVector(a.normal,side*(track.width/2+2.58));
      brakeLabels.push({p:p.clone().setY(p.y+1.16),r:a.heading,s:[.5,.72,.22]});
    });
    addInstances(group,new T.BoxGeometry(1,1,1),dark,brakeLabels);
    // A compact pit-lane ribbon gives every circuit a recognizable paddock side without expensive geometry.
    if(Number.isFinite(track.pit)){
      const a=APEX_TRACKS.at(track,track.pit*track.length),side=a.normal.clone().multiplyScalar(track.kind==='monaco'||track.kind==='singapore'?1:-1);
      const base=a.p.clone().addScaledVector(side,track.width*.72),pit=box(group,mat(0x555d60,.9),base.x,base.y+.04,base.z,track.width*.55,.035,7.5);
      pit.rotation.y=a.heading; pit.name='Pit lane entry';
      const garage=[];for(let i=0;i<5;i++){const q=base.clone().addScaledVector(a.tangent,(i-2)*3.2).addScaledVector(side,4);garage.push({p:q.clone().setY(q.y+1.1),r:a.heading,s:[2.3,2.2,1.4]})}
      addInstances(group,new T.BoxGeometry(1,1,1),dark,garage);
    }
    // Lightweight overhead DRS markers.
    const drs=[];(track.drs||[]).forEach(z=>{
      const a=APEX_TRACKS.at(track,z[0]*track.length),p=a.p.clone();
      drs.push({p:p.clone().setY(p.y+3.5),r:a.heading,s:[track.width*.9,.16,.16]});
    });
    addInstances(group,new T.BoxGeometry(1,1,1),red,drs);
  }

  function makeTerrain(track,b){
    const seg=56,rows=56,pos=[],ind=[];
    const x0=b.minX-90,x1=b.maxX+90,z0=b.minZ-90,z1=b.maxZ+90,base=-2;
    for(let iz=0;iz<=rows;iz++){const z=z0+(z1-z0)*iz/rows;for(let ix=0;ix<=seg;ix++){const x=x0+(x1-x0)*ix/seg;let nearest=Infinity,ny=base;
      for(let k=0;k<track.count;k+=10){const q=track.samples[k].p,dx=x-q.x,dz=z-q.z,d2=dx*dx+dz*dz;if(d2<nearest){nearest=d2;ny=q.y;}}
      const d=Math.sqrt(nearest);let y=base; if(d<34)y=Math.max(base,ny-1.0-d*.018);
      // Broader landscape rise for non-street circuits.
      if(track.terrain==='hills'||track.terrain==='forest')y+=Math.max(0,1-Math.min(1,Math.hypot((x-b.cx)/(b.w*.9),(z-b.cz)/(b.d*.9))))*.8;
      pos.push(x,y,z);}}
    for(let iz=0;iz<rows;iz++)for(let ix=0;ix<seg;ix++){const q=iz*(seg+1)+ix,j=q+seg+1;ind.push(q,j,j+1,q,j+1,q+1)}
    const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(pos,3));geo.setIndex(ind);geo.computeVertexNormals();return new T.Mesh(geo,mat(track.kind==='singapore'?0x09131d:0x23452c,.98));
  }

  function addScenery(group,track){
    const b=trackBounds(track),margin=Math.max(90,b.span*.32),ground=mat(track.kind==='monaco'?0x26343a:track.kind==='singapore'?0x09131d:track.kind==='monza'||track.kind==='silverstone'||track.kind==='spa'||track.kind==='suzuka'||track.kind==='interlagos'?0x23452c:0x1a3b2d);
    group.add(makeTerrain(track,b));
    const curbMat=mat(0xd64f4b,.8); // one continuous road boundary per side
    group.add(makeBoundary(track,1),makeBoundary(track,-1));
    if(track.kind==='street'||track.kind==='monaco'||track.kind==='singapore'){
      const wallA=mat(0x56646b,.68,.25,{side:T.DoubleSide}),wallB=mat(0x263a40,.72,.18,{side:T.DoubleSide});group.add(makeWall(track,1,wallA),makeWall(track,-1,wallB));
      addStreetScenery(group,track,b);
      addThemeScenery(group,track,b);
    }else{
      // Low alternating curb blocks are batched; they do not sit on the racing surface.
      const curb=[];for(let i=0;i<track.count;i+=4){const f=frame(track,i);[-1,1].forEach(side=>{const p=f.s.p.clone().addScaledVector(f.n,side*(track.width/2+.56));if(sceneryClear(track,p,track.width/2+.35))curb.push({p:p.clone().add(new T.Vector3(0,.12,0)),r:Math.atan2(f.t.x,f.t.z),s:[1.15,.18,.5]})})}
      addInstances(group,new T.BoxGeometry(1,1,1),curbMat,curb);
      addTrees(group,track,track.kind==='park');if(track.kind==='airfield')addAirfield(group,track,b);addThemeScenery(group,track,b);
    }
    // Runoff ribbons on permanent circuits follow elevation and banking, giving corners believable safety space.
    if(track.kind!=='monaco'&&track.kind!=='singapore'){
      const runoffMat=mat(track.kind==='spa'||track.kind==='suzuka'?0x3b5745:0x5b5145,.95);
      const strips=[];for(let i=0;i<track.count;i+=2){const f=frame(track,i);[-1,1].forEach(side=>{const p=f.s.p.clone().addScaledVector(f.n,side*(track.width/2+3.8));strips.push({p:p.clone().setY(p.y-.02),r:Math.atan2(f.t.x,f.t.z),s:[4.8,.035,1.9]})})}
      addInstances(group,new T.BoxGeometry(1,1,1),runoffMat,strips);
    }
    const stands=[];for(let i=0;i<5;i++){const idx=(i*137+43)%track.count,f=frame(track,idx),side=i%2?1:-1,p=f.s.p.clone().addScaledVector(f.n,side*(track.width/2+14));if(!sceneryClear(track,p,10))continue;stands.push({p:p.clone().setY(p.y+1.4),r:Math.atan2(f.t.x,f.t.z),s:[10,2.8,3.2]})}
    if(track.kind!=='monaco'&&track.kind!=='singapore')addInstances(group,new T.BoxGeometry(1,1,1),mat(0x667072,.82),stands);
    // Starting gantry: top bar is across the track, sharing the finish-line normal orientation.
    const f=frame(track,0),s=f.s,accentMat=mat(track.color,.35,.2);[-1,1].forEach(side=>{const p=s.p.clone().addScaledVector(f.n,side*7.2);box(group,accentMat,p.x,p.y+2.4,p.z,.35,4.8,.35)});
    const top=box(group,accentMat,s.p.x,s.p.y+4.55,s.p.z,14.8,.38,.5);top.rotation.y=Math.atan2(f.t.x,f.t.z);
  }
  function disposeObject(root){if(!root)return;root.traverse(o=>{if(o.geometry&&o.geometry.dispose)o.geometry.dispose();if(o.material){const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>{if(m&&m.dispose)m.dispose()})}})}
  function World(container){
    this.container=container;this.scene=new T.Scene();this.camera=new T.PerspectiveCamera(58,1,.1,1200);this.camera.position.set(0,8,13);this.renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.65));this.renderer.shadowMap.enabled=false;this.renderer.outputEncoding=T.sRGBEncoding;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=.8;container.appendChild(this.renderer.domElement);this.cars=new T.Group();this.scene.add(this.cars);this.carMeshes=[];this.follow=new T.Vector3();this.cameraMode='chase';
    const hemi=new T.HemisphereLight(0xc2dbef,0x303b29,.7);this.scene.add(hemi);const sun=new T.DirectionalLight(0xfff4dc,1.1);sun.position.set(-80,120,60);sun.castShadow=false;this.scene.add(sun);this.scene.fog=new T.Fog(0x7fa4a0,180,500);this.scene.background=new T.Color(0x7fa4a0);
    const observe=()=>{this.resize()};
    this.resize=()=>{const host=this.renderer.domElement.parentElement||container;if(this._resizeObserver&&this._resizeHost!==host){this._resizeObserver.disconnect();this._resizeObserver.observe(host);this._resizeHost=host}const r=host.getBoundingClientRect?host.getBoundingClientRect():{width:host.clientWidth,height:host.clientHeight};const w=Math.max(1,Math.floor(r.width||host.clientWidth||window.innerWidth||1)),h=Math.max(1,Math.floor(r.height||host.clientHeight||window.innerHeight||1));this.camera.aspect=w/Math.max(1,h);this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false)};
    if(window.ResizeObserver){this._resizeObserver=new ResizeObserver(observe);this._resizeObserver.observe(container)}window.addEventListener('resize',observe);this.resize();
  }
  World.prototype.build=function(track,states){
    if(this.environment){this.scene.remove(this.environment);disposeObject(this.environment)}
    this.environment=new T.Group();this.scene.add(this.environment);addScenery(this.environment,track);this.environment.add(makeRoad(track));addTrackDetails(this.environment,track);
    const lineMat=mat(0xf6f1dc),s=track.samples[0],f=frame(track,0),line=box(this.environment,lineMat,s.p.x,.09,s.p.z,track.width,.025,.7);line.rotation.y=Math.atan2(f.t.x,f.t.z);
    const b=trackBounds(track),fogNear=Math.max(180,Math.min(260,b.span*.28)),fogFar=Math.max(420,Math.min(600,b.span*1.05));this.scene.fog.near=fogNear;this.scene.fog.far=fogFar;this.camera.far=Math.max(1000,b.span*2.4+300);this.camera.updateProjectionMatrix();const night=track.kind==='singapore';this.scene.fog.color.set(night?0x07101b:(track.kind==='monaco'?0x6e9aa5:track.kind==='spa'?0x769b88:track.kind==='suzuka'?0x8aa0a0:0x8aa393));this.scene.background.copy(this.scene.fog.color);this.scene.fog.near=night?130:fogNear;this.scene.fog.far=night?430:fogFar;this.scene.backgroundIntensity=night?.35:1;
    this.carMeshes.forEach(disposeObject);while(this.cars.children.length)this.cars.remove(this.cars.children[0]);this.carMeshes=[];states.forEach((st,i)=>{const m=buildCar(st.team,i===0);this.cars.add(m);this.carMeshes.push(m)});this.track=track;this._snapCamera=true;if(states[0])this.updateCamera(states[0],0);
  };
  World.prototype.updateCars=function(states,playerIndex){if(!this.track)return;states.forEach((st,i)=>{const a=APEX_TRACKS.at(this.track,st.u),p=a.p.clone().addScaledVector(a.normal,st.lateral),m=this.carMeshes[i];if(!m)return;m.position.set(p.x,p.y+.13,p.z);m.rotation.y=a.heading+(st.headingError||0);m.scale.setScalar(i===playerIndex?1.03:1);});};
  World.prototype.updateCamera=function(player,dt){if(!this.track)return;const a=APEX_TRACKS.at(this.track,player.u),p=a.p.clone().addScaledVector(a.normal,player.lateral||0),forward=a.tangent.clone().normalize();let target,desired;if(this.cameraMode==='cockpit'){desired=p.clone().add(new T.Vector3(0,1.12,0)).addScaledVector(forward,-.35);target=p.clone().add(new T.Vector3(0,.9,0)).addScaledVector(forward,13)}else{desired=p.clone().add(new T.Vector3(0,4.2,0)).addScaledVector(forward,-8.8);target=p.clone().add(new T.Vector3(0,1.0,0)).addScaledVector(forward,10+Math.min((player.speed||0)*.035,7))}if(this._snapCamera){this.camera.position.copy(desired);this.follow.copy(target);this._snapCamera=false}else{this.camera.position.lerp(desired,1-Math.pow(.0008,Math.max(0,dt)));this.follow.lerp(target,1-Math.pow(.0003,Math.max(0,dt)))}this.camera.lookAt(this.follow)};
  World.prototype.render=function(){this.renderer.render(this.scene,this.camera)};World.prototype.toggleCamera=function(){this.cameraMode=this.cameraMode==='chase'?'cockpit':'chase';return this.cameraMode};window.APEX_WORLD={World};
})();
