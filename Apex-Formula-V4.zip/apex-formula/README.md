# APEX FORMULA V4

Mobile-first lightweight formula racing prototype.

## V4 track system

V4 replaces the previous flat procedural circuit presentation with authored, circuit-specific centerlines for:

- Monaco
- Monza
- Silverstone
- Spa-Francorchamps
- Suzuka
- Interlagos
- Singapore

Each circuit now contains detailed corner-by-corner control points, a target circuit length, an elevation profile and corner banking values. The runtime samples those paths at high resolution and uses the resulting 3D surface for the road, curbs, barriers, runoff, cars and camera.

The environments remain deliberately low-poly / instanced so the game can target lower-RAM Android hardware.

## Accuracy note

These are high-detail gameplay recreations/approximations, not survey-grade CAD reproductions. The source does not include licensed photogrammetry or surveyed engineering geometry. The V4 system is designed so surveyed centerline/elevation data can be dropped in later without rewriting the renderer.

## Controls

- Touch: steer, throttle, brake, DRS and PASS/ERS
- Keyboard: arrow/WASD controls plus DRS/ERS shortcuts already present in the game

## Run

Open `index.html` in a modern WebGL-capable browser. A local/static server is recommended for browser security compatibility.
