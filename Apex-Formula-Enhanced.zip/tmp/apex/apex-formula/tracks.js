/* Mathematical circuit data. Layouts are original, simplified inspirations. */
(function(){
  'use strict';
  const defs=[
    {id:'riviera',name:'Riviera Run',short:'Monaco · inspired',kind:'street',difficulty:'Technical',description:'A technical waterfront street loop with walls, tight turns and a harbour backdrop.',lengthHint:'3.18 km',color:'#35e2d0',control:[[-2,-72],[30,-80],[72,-63],[88,-18],[79,21],[48,36],[66,64],[38,82],[-6,79],[-47,69],[-70,38],[-67,5],[-87,-17],[-72,-47],[-42,-66]]},
    {id:'autostrada',name:'Autostrada Verde',short:'Monza · inspired',kind:'park',difficulty:'Fast',description:'Long blasts through a green park, hard brakes and two quick chicanes.',lengthHint:'4.12 km',color:'#8bdc75',control:[[-12,-104],[67,-103],[94,-74],[86,-47],[42,-54],[22,-28],[67,-2],[79,30],[44,45],[3,36],[-31,66],[-84,75],[-102,45],[-89,13],[-49,18],[-66,-20],[-102,-35],[-92,-76]]},
    {id:'airfield',name:'Northstar Flow',short:'Silverstone · inspired',kind:'airfield',difficulty:'Balanced',description:'A broad airfield loop with flowing esses, fast sweepers and grandstands.',lengthHint:'3.74 km',color:'#e7c66a',control:[[-10,-102],[36,-100],[79,-76],[100,-40],[94,-2],[58,12],[78,42],[65,83],[17,99],[-22,84],[-55,101],[-91,78],[-76,40],[-35,27],[-69,-3],[-89,-39],[-62,-72]]}
  ];
  function mod(n,m){return ((n%m)+m)%m}
  function make(def){
    const points=def.control.map(p=>new THREE.Vector3(p[0]*2.5,0,p[1]*2.5));
    const curve=new THREE.CatmullRomCurve3(points,true,'centripetal',0.45);
    curve.arcLengthDivisions=3000;
    const count=720;
    const raw=curve.getSpacedPoints(count).slice(0,-1);
    const samples=[]; let length=0;
    for(let i=0;i<count;i++){
      const p=raw[i], next=raw[(i+1)%count], prev=raw[(i+count-1)%count];
      const tangent=new THREE.Vector3().subVectors(next,prev).normalize();
      const heading=Math.atan2(tangent.x,tangent.z);
      const diff=Math.atan2(next.x-p.x,next.z-p.z)-Math.atan2(p.x-prev.x,p.z-prev.z);
      const curvature=Math.atan2(Math.sin(diff),Math.cos(diff))/Math.max(.01,(next.distanceTo(p)+p.distanceTo(prev))*.5);
      if(i>0) length+=p.distanceTo(raw[i-1]);
      samples.push({p:p.clone(),tangent,heading,curvature,dist:length});
    }
    length+=raw[0].distanceTo(raw[count-1]);
    return Object.assign({},def,{curve,samples,count,length,lengthHint:(length/1000).toFixed(2)+' km',width:def.kind==='street'?12:14,startD:0});
  }
  function at(track,u){
    const d=mod(u,track.length), f=d/track.length*track.count;
    const i=Math.floor(f), n=(i+1)%track.count, t=f-i, a=track.samples[i],b=track.samples[n];
    const p=a.p.clone().lerp(b.p,t); const tangent=a.tangent.clone().lerp(b.tangent,t).normalize();
    const normal=new THREE.Vector3(tangent.z,0,-tangent.x).normalize();
    return {p,tangent,normal,heading:Math.atan2(tangent.x,tangent.z),curvature:a.curvature};
  }
  function outline(track,w,h){
    const pts=track.samples; let minX=Infinity,maxX=-Infinity,minZ=Infinity,maxZ=-Infinity;
    pts.forEach(s=>{minX=Math.min(minX,s.p.x);maxX=Math.max(maxX,s.p.x);minZ=Math.min(minZ,s.p.z);maxZ=Math.max(maxZ,s.p.z)});
    const sx=(w-14)/(maxX-minX), sz=(h-14)/(maxZ-minZ), scale=Math.min(sx,sz);
    return pts.map(s=>({x:7+(s.p.x-minX)*scale+(w-(maxX-minX)*scale-14)/2,y:7+(s.p.z-minZ)*scale+(h-(maxZ-minZ)*scale-14)/2}));
  }
  window.APEX_TRACKS={defs,make,at,outline,mod};
})();
