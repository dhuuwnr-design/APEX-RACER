/* Apex Formula session simulation and interface. No persistence or external APIs. */
(function(){
  'use strict';
  const $=id=>document.getElementById(id); const TA=window.APEX_TRACKS;
  const teams=[
    {name:'Apex Carbon',short:'APX',body:0x12282e,accent:0x35e2d0},
    {name:'Vanta Works',short:'VNT',body:0xb6473f,accent:0xf0c06b},
    {name:'Northline',short:'NTH',body:0x3453a5,accent:0x92d9ee},
    {name:'Helio GP',short:'HEL',body:0xd19c32,accent:0xf5f0d4},
    {name:'Kestrel Racing',short:'KST',body:0x813c74,accent:0xf2a8d3},
    {name:'Bracken Sport',short:'BRK',body:0x3d805a,accent:0xc3ee9e},
    {name:'Vector House',short:'VEC',body:0x78838a,accent:0xdfe8e6},
    {name:'Ion Motorsport',short:'ION',body:0x913a33,accent:0xef7c66}
  ];
  const tracks=TA.defs.map(TA.make); let selected=tracks[0],world=null,phase='menu',states=[],player=null,laps=3,mode='race',raceTime=0,accumulator=0,lastFrame=0,countdown=0,assist=true,autoThrottle=false,cameraMode='chase',muted=false,outlineCache=new Map(),menuPlayer=null;
  const input={left:false,right:false,throttle:false,brake:false};
  let audioCtx=null,engineOsc=null,engineGain=null;
  function startAudio(){try{if(audioCtx){audioCtx.resume();return;}audioCtx=new (window.AudioContext||window.webkitAudioContext)();engineOsc=audioCtx.createOscillator();engineGain=audioCtx.createGain();engineOsc.type='sawtooth';engineOsc.frequency.value=75;engineGain.gain.value=0.0001;engineOsc.connect(engineGain).connect(audioCtx.destination);engineOsc.start();audioCtx.resume()}catch(err){console.warn('Optional engine audio unavailable',err)}}
  function updateAudio(){if(!engineOsc||!engineGain||!audioCtx)return;const loud=muted||(phase!=='race'&&phase!=='countdown')?0:Math.min(.025,.004+(player?player.speed/2700:0));engineGain.gain.setTargetAtTime(loud,audioCtx.currentTime,.06);engineOsc.frequency.setTargetAtTime(65+(player?player.speed*2.8:0),audioCtx.currentTime,.06)}
  function stopAudio(){if(engineOsc){try{engineOsc.stop()}catch(_){}}if(audioCtx)audioCtx.close().catch(()=>{});engineOsc=null;engineGain=null;audioCtx=null}
  function safeText(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
  function timeText(seconds){if(!Number.isFinite(seconds))return '--:--.---';const m=Math.floor(seconds/60),s=seconds-m*60;return String(m).padStart(2,'0')+':'+s.toFixed(3).padStart(6,'0')}
  function ordinal(n){return n===1?'1st':n===2?'2nd':n===3?'3rd':n+'th'}
  function createTrackCards(){const holder=$('trackCards');holder.innerHTML='';tracks.forEach((track,i)=>{const button=document.createElement('button');button.className='track-card'+(track.id===selected.id?' selected':'');button.dataset.id=track.id;const canvas=document.createElement('canvas');canvas.className='track-map';canvas.width=240;canvas.height=90;const ctx=canvas.getContext('2d');const pts=TA.outline(track,240,90);ctx.strokeStyle='rgba(231,244,243,.15)';ctx.lineWidth=8;ctx.lineCap='round';ctx.beginPath();pts.forEach((p,j)=>j?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.strokeStyle=track.color;ctx.lineWidth=2;ctx.beginPath();pts.forEach((p,j)=>j?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.fillStyle=track.color;ctx.beginPath();ctx.arc(pts[0].x,pts[0].y,3,0,Math.PI*2);ctx.fill();button.appendChild(canvas);const title=document.createElement('h3');title.textContent=track.name;button.appendChild(title);const origin=document.createElement('small');origin.className='track-origin';origin.textContent=track.short;button.appendChild(origin);const desc=document.createElement('p');desc.textContent=track.description;button.appendChild(desc);const meta=document.createElement('div');meta.className='track-meta';meta.innerHTML='<span>'+track.difficulty+'</span><span>'+track.lengthHint+'</span>';button.appendChild(meta);button.addEventListener('click',()=>{selected=track;document.querySelectorAll('.track-card').forEach(x=>x.classList.toggle('selected',x===button));if(world&&phase==='menu')showPreview()});holder.appendChild(button)})}
  function setupInputs(){
    const set=(key,val)=>{input[key]=val};
    window.addEventListener('keydown',e=>{if(phase==='menu'||phase==='finished'||/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;const k=e.key.toLowerCase();if(e.repeat&&['p','escape','r','c'].includes(k))return;let used=true;if(k==='a'||k==='arrowleft')set('left',true);else if(k==='d'||k==='arrowright')set('right',true);else if(k==='w'||k==='arrowup')set('throttle',true);else if(k==='s'||k==='arrowdown'||k===' ')set('brake',true);else if(k==='p'||k==='escape'){togglePause();}else if(k==='r'){recoverPlayer()}else if(k==='c'){toggleCamera()}else used=false;if(used)e.preventDefault()});window.addEventListener('keyup',e=>{const k=e.key.toLowerCase();if(k==='a'||k==='arrowleft')set('left',false);if(k==='d'||k==='arrowright')set('right',false);if(k==='w'||k==='arrowup')set('throttle',false);if(k==='s'||k==='arrowdown'||k===' ')set('brake',false)});
    window.addEventListener('blur',()=>{clearInput();if(phase==='race'||phase==='countdown')pause(true)});document.addEventListener('visibilitychange',()=>{if(document.hidden){clearInput();if(phase==='race'||phase==='countdown')pause(true)}});
    document.querySelectorAll('.touch-btn').forEach(btn=>{const key=btn.dataset.control;const on=e=>{e.preventDefault();btn.classList.add('active');set(key,true);try{btn.setPointerCapture(e.pointerId)}catch(_){}};const off=e=>{e.preventDefault();btn.classList.remove('active');set(key,false)};btn.addEventListener('pointerdown',on);btn.addEventListener('pointerup',off);btn.addEventListener('pointercancel',off);btn.addEventListener('lostpointercapture',off)});
  }
  function clearInput(){Object.keys(input).forEach(k=>input[k]=false);document.querySelectorAll('.touch-btn').forEach(b=>b.classList.remove('active'))}
  function makeStates(){const total=mode==='practice'?1:8;states=[];for(let i=0;i<total;i++){const t=teams[i];states.push({id:i,name:i===0?'APEX CARBON':t.short+' '+t.name.split(' ')[0],team:t,u:-9-Math.floor(i/2)*10,lateral:i%2?1.8:-1.8,speed:0,lap:0,started:false,nextLine:1,lapStart:0,lapTimes:[],bestLap:Infinity,finished:false,finishTime:Infinity,topSpeed:0,latVel:0,headingError:0,steer:0,rank:i+1,aiSeed:i*2.13+1})}player=states[0]}
  function showPreview(){if(!world)return;makeStates();menuPlayer={...player,u:selected.length*.18,speed:34,lateral:0};world.build(selected,[menuPlayer]);world.updateCars([menuPlayer],0)}
  function startRace(){clearInput();startAudio();selected=tracks.find(t=>t.id===selected.id)||tracks[0];laps=Number($('lapsSelect').value)||3;mode=$('modeSelect').value;assist=$('assistToggle').checked;autoThrottle=$('autoThrottleToggle').checked;makeStates();$('menu').classList.add('hidden');$('results').classList.add('hidden');$('race').classList.remove('hidden');$('pauseOverlay').classList.add('hidden');if(world.renderer.domElement.parentElement!==$('viewport'))$('viewport').appendChild(world.renderer.domElement);world.build(selected,states);world.resize();world.updateCars(states,0);world.updateCamera(player,1);raceTime=0;accumulator=0;countdown=3.55;phase='countdown';$('countdown').textContent='3';$('raceHint').textContent=mode==='practice'?'PRACTICE · no traffic':'FIND YOUR LINE · brake before the corners';updateHUD();drawMinimap();}
  function recoverPlayer(){if(!player||phase==='menu'||phase==='finished')return;player.lateral=0;player.latVel=0;player.headingError=0;player.steer=0;player.speed=Math.min(player.speed,12);if(!Number.isFinite(player.u))player.u=0;}
  function togglePause(){if(phase==='race'||phase==='countdown')pause(true);else if(phase==='paused')pause(false)}
  function pause(force){if(force===true&&phase!=='race'&&phase!=='countdown')return;if(force===false&&phase!=='paused')return;if(phase==='paused'){phase=countdown>0?'countdown':'race';$('pauseOverlay').classList.add('hidden')}else{phase='paused';clearInput();$('pauseOverlay').classList.remove('hidden')}}
  function toggleCamera(){if(!world||phase==='menu')return;cameraMode=world.toggleCamera();$('cameraBtn').textContent=cameraMode==='chase'?'◉':'◎'}
  function cornerSpeed(u,grip=15){const k=Math.abs(TA.at(selected,u).curvature);return Math.min(selected.kind==='street'?67:79,Math.sqrt(grip/Math.max(k,.0015)))}
  function simulatePlayer(dt){
    const p=player;if(p.finished)return;
    const brake=input.brake?1:0,throttle=(autoThrottle||input.throttle)&&!brake?1:0;
    const steer=(input.left?1:0)-(input.right?1:0),a=TA.at(selected,p.u);
    const max=selected.kind==='street'?74:86;
    const acceleration=throttle*29*(1-p.speed/max)-brake*48-1.6-.0015*p.speed*p.speed;
    p.speed=Math.max(0,Math.min(max,p.speed+acceleration*dt));p.topSpeed=Math.max(p.topSpeed,p.speed);
    p.steer+=(steer-p.steer)*Math.min(1,dt*7);
    const desiredYaw=p.steer*p.speed*.19/(3.2*(1+p.speed/38));
    const feedForward=assist?(a.curvature*p.speed-p.headingError*2.8-p.lateral*.045):0;
    const maxYaw=17/Math.max(6,p.speed);
    const yaw=Math.max(-maxYaw,Math.min(maxYaw,desiredYaw+feedForward));
    const along=p.speed*Math.max(.15,Math.cos(p.headingError))/Math.max(.5,1-a.curvature*p.lateral);
    p.headingError=Math.max(-1.1,Math.min(1.1,p.headingError+(yaw-a.curvature*along)*dt));
    p.lateral+=p.speed*Math.sin(p.headingError)*dt;
    const edge=selected.width/2-1.15;
    if(Math.abs(p.lateral)>edge){
      p.speed*=Math.exp(-(selected.kind==='street'?1.8:1.25)*dt);
      const limit=edge+(selected.kind==='street'?.4:3);
      if(Math.abs(p.lateral)>limit){p.lateral=Math.sign(p.lateral)*limit;p.headingError-=Math.sign(p.lateral)*dt*1.6;}
    }
    p.u+=along*dt;checkLine(p);
  }
  function simulateAI(st,dt){
    if(st.finished)return;
    let target=cornerSpeed(st.u,12.5);
    for(let ahead=12;ahead<=110;ahead+=14){const v=cornerSpeed(st.u+ahead,12.5);target=Math.min(target,Math.sqrt(v*v+2*19*ahead));}
    target*=.90+st.id*.009;
    const lane=Math.sin(st.aiSeed+st.u*.006)*1.15+(st.id%2?-.8:.8);
    st.lateral+=(lane-st.lateral)*Math.min(1,dt*1.4);
    st.speed=Math.max(0,st.speed+Math.max(-40,Math.min(23,(target-st.speed)*2))*dt);
    st.topSpeed=Math.max(st.topSpeed,st.speed);st.u+=st.speed*dt;checkLine(st);
  }
  function checkLine(st){
    if(st.finished)return;
    if(!st.started&&st.u>=0){st.started=true;st.nextLine=1;}
    while(st.started&&st.u>=st.nextLine*selected.length&&!st.finished){
      const lapTime=raceTime-st.lapStart;st.lapTimes.push(lapTime);st.bestLap=Math.min(st.bestLap,lapTime);st.lapStart=raceTime;st.lap++;st.nextLine++;
      if(st.lap>=laps){st.finished=true;st.finishTime=raceTime;st.speed=0;}
    }
  }
  function contacts(){for(let i=0;i<states.length;i++)for(let j=i+1;j<states.length;j++){const a=states[i],b=states[j];if(a.finished||b.finished)continue;const distance=Math.abs(TA.mod(a.u-b.u+selected.length/2,selected.length)-selected.length/2);if(distance<4.4&&Math.abs(a.lateral-b.lateral)<2.1){const push=a.lateral<=b.lateral?-.035:.035;a.lateral+=push;b.lateral-=push;a.speed*=.997;b.speed*=.997}}}
  function updateRanks(){const ordered=[...states].sort((a,b)=>{if(a.finished!==b.finished)return a.finished?-1:1;if(a.finished)return a.finishTime-b.finishTime;return b.u-a.u});ordered.forEach((s,i)=>s.rank=i+1)}
  function physics(dt){if(phase==='countdown'){return}if(phase!=='race')return;raceTime+=dt;simulatePlayer(dt);states.slice(1).forEach(s=>simulateAI(s,dt));contacts();updateRanks();if(player.finished){phase='finished';setTimeout(showResults,650)}}
  function updateHUD(){if(!player)return;const total=states.length;const lapShown=Math.min(laps,player.lap+1);$('lapValue').textContent=lapShown+' / '+laps;$('lapProgress').textContent=player.finished?'100%':Math.round(Math.max(0,TA.mod(Math.max(0,player.u),selected.length)/selected.length*100))+'%';$('positionValue').innerHTML=(player.rank||1)+'<small> / '+total+'</small>';$('gapValue').textContent=phase==='countdown'?'GRID':player.rank===1?'LEAD':'TO LEADER';$('timerValue').textContent=timeText(raceTime);$('speedValue').textContent=Math.round(player.speed*3.6);$('gearValue').textContent=player.speed<1?'N':String(Math.min(8,Math.max(1,Math.floor(player.speed/9)+1)));$('rpmFill').style.width=Math.min(100,25+(player.speed%9)/9*75)+'%';const ordered=[...states].sort((a,b)=>(a.rank||9)-(b.rank||9));$('timingRows').innerHTML=ordered.map(s=>'<div class="timing-row '+(s===player?'player':'')+'"><span class="pos">'+(s.rank||'–')+'</span><strong>'+safeText(s.name)+'</strong><span class="time">'+(s.finished?'FLAG':s===player?'YOU':'+'+Math.max(0,(ordered[0].u-s.u)/Math.max(15,s.speed)).toFixed(1))+'</span></div>').join('');if(phase==='race'){$('raceHint').textContent=Math.abs(player.lateral)>selected.width/2-1.2?'OFF LINE · brake and steer back · R / ↺ to recover':player.speed>cornerSpeed(player.u+24,15)*1.12?'BRAKE FOR THE CORNER':'W / ↑ accelerate · S / ↓ brake · A / D steer · P pause';}}
  function drawMinimap(){const c=$('minimap'),ctx=c.getContext('2d'),w=c.width,h=c.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='rgba(6,18,22,.75)';ctx.fillRect(0,0,w,h);const pts=outlineCache.get(selected.id)||TA.outline(selected,w,h);outlineCache.set(selected.id,pts);ctx.lineCap='round';ctx.lineJoin='round';ctx.strokeStyle='rgba(231,244,243,.2)';ctx.lineWidth=8;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();ctx.strokeStyle=selected.color;ctx.lineWidth=2;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.stroke();states.forEach((s,i)=>{const f=TA.mod(s.u,selected.length)/selected.length*pts.length,idx=Math.floor(f)%pts.length,p=pts[idx];ctx.fillStyle=i===0?'#35e2d0':teams[i].accent?'#f0c06b':'#fff';ctx.beginPath();ctx.arc(p.x,p.y,i===0?4:2.5,0,Math.PI*2);ctx.fill()})}
  function showResults(){stopAudio();updateRanks();$('race').classList.add('hidden');$('results').classList.remove('hidden');$('resultTitle').textContent=player.finished?'You made the flag':'Session complete';$('resultPosition').textContent=ordinal(player.rank||1);$('resultTrack').textContent=selected.short.toUpperCase();$('resultTime').textContent=timeText(player.finishTime);$('resultBest').textContent=timeText(player.bestLap);$('resultSpeed').innerHTML=Math.round(player.topSpeed*3.6)+' <em>km/h</em>';$('resultTable').innerHTML=[...states].sort((a,b)=>(a.rank||9)-(b.rank||9)).map(s=>'<div class="timing-row '+(s===player?'player':'')+'"><span class="pos">'+s.rank+'</span><strong>'+safeText(s.name)+'</strong><span class="time">'+(s.finished?timeText(s.finishTime):'BEHIND · LAP '+(s.lap+1))+'</span></div>').join('')}
  function backToMenu(){stopAudio();phase='menu';clearInput();$('results').classList.add('hidden');$('race').classList.add('hidden');$('menu').classList.remove('hidden');$('pauseOverlay').classList.add('hidden');if(world&&world.renderer.domElement.parentElement!==$('menuWorld'))$('menuWorld').appendChild(world.renderer.domElement);showPreview()}
  let hudClock=0;
  function raf(now){if(!lastFrame)lastFrame=now;const dt=Math.min(.08,(now-lastFrame)/1000);lastFrame=now;if(phase==='countdown'){countdown-=dt;if(countdown<=0){phase='race';raceTime=0}else{$('countdown').textContent=countdown>2.65?'3':countdown>1.75?'2':countdown>.75?'1':'GO'}}if(phase==='race'||phase==='countdown'){accumulator+=dt;while(accumulator>=1/60){physics(1/60);accumulator-=1/60}world.updateCars(states,0);world.updateCamera(player,dt);world.render();if(phase!=='countdown')$('countdown').textContent='';hudClock+=dt;if(hudClock>.10){updateHUD();drawMinimap();hudClock=0;}}else if(phase==='menu'&&world&&menuPlayer){world.updateCamera(menuPlayer,dt);world.render();}updateAudio();requestAnimationFrame(raf)}
  function fatal(err){console.error('Apex Formula failed to initialize',err);$('fatal').textContent='APEX FORMULA could not start.\n\n'+(err&&err.message?err.message:String(err))+'\n\nTry a browser with WebGL enabled.';$('fatal').classList.remove('hidden')}
  function init(){try{createTrackCards();setupInputs();world=new APEX_WORLD.World($('menuWorld'));showPreview();$('startBtn').addEventListener('click',startRace);$('pauseBtn').addEventListener('click',togglePause);$('recoverBtn').addEventListener('click',recoverPlayer);$('resumeBtn').addEventListener('click',()=>pause(false));$('restartPauseBtn').addEventListener('click',startRace);$('quitBtn').addEventListener('click',backToMenu);$('cameraBtn').addEventListener('click',toggleCamera);$('muteBtn').addEventListener('click',()=>{muted=!muted;$('muteBtn').textContent=muted?'×♫':'♫'});$('againBtn').addEventListener('click',startRace);$('changeTrackBtn').addEventListener('click',backToMenu);requestAnimationFrame(raf)}catch(err){fatal(err)}}
  window.APEX_STATUS=()=>({phase,track:selected.id,raceTime,countdown,laps,camera:world?world.cameraMode:null,drawCalls:world?world.renderer.info.render.calls:0,player:player?{u:player.u,speed:player.speed,lateral:player.lateral,headingError:player.headingError,lap:player.lap,rank:player.rank,finished:player.finished,lapTimes:[...player.lapTimes]}:null});
  window.addEventListener('load',init);
})();
