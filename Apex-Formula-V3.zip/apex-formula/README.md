# Apex Formula — playable prototype

A browser-based, original open-wheel arcade racer built with Three.js.

## Play
Open the Tasklet app preview and choose a circuit, distance and mode. Press **Start Engine**.

- **Riviera Run**: Monaco-inspired waterfront street loop.
- **Autostrada Verde**: Monza-inspired park circuit.
- **Northstar Flow**: Silverstone-inspired airfield circuit.

These are simplified original layouts, not accurate replicas. Distances are computed from the prototype geometry.

## Controls
- W / Up: accelerate
- S / Down / Space: brake
- A / D or Left / Right: steer
- P / Escape: pause
- R or the ↺ button: recover to track centre
- C or the camera button: chase / cockpit view
- Sound button: mute / unmute

Touch controls support simultaneous steering and pedals. Landscape is recommended on phones; optional auto-throttle reduces the number of touches needed. Steering assist helps hold a line, but overspeed still causes understeer and off-track slowing.

## Scope
Includes an eight-car AI race or solo practice, 1/3/5 laps, automatic gears, live positions, minimap, timing, race results, and optional basic engine sound. Results are session-only.

Not included: official licensed teams, photorealism, advanced simulation physics, pit strategy, tyre compounds, damage, weather, championships, or multiplayer. This is not equivalent to Monoposto.

## Portability
The source files can be hosted together on a static website. A modern WebGL browser and internet access to jsDelivr are required for the rendering and interface libraries. No account, backend, or AI calls are used during gameplay.
